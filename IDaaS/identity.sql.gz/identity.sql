-- MySQL dump 10.13  Distrib 5.6.16, for osx10.7 (x86_64)
--
-- Host: localhost    Database: identity_information
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `household`
--

DROP TABLE IF EXISTS `household`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `household` (
  `householdID` int(11) NOT NULL,
  `DefaultUser` varchar(20) NOT NULL,
  `operatorID` int(11) DEFAULT NULL,
  `subscription_tier` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `max_devices` int(11) DEFAULT NULL,
  `parental_rating` int(11) DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`householdID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `household`
--

LOCK TABLES `household` WRITE;
/*!40000 ALTER TABLE `household` DISABLE KEYS */;
INSERT INTO `household` VALUES (1,'dad1',1,'extreme','activated',3,10,'2014-05-13 00:00:00','2014-05-13 00:00:00','dad1');
/*!40000 ALTER TABLE `household` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `householdID` int(11) NOT NULL,
  `city` varchar(10) DEFAULT NULL,
  `region` varchar(10) DEFAULT NULL,
  `postcode` int(11) DEFAULT NULL,
  `country` varchar(3) DEFAULT NULL,
  KEY `householdID` (`householdID`),
  CONSTRAINT `location_ibfk_1` FOREIGN KEY (`householdID`) REFERENCES `household` (`householdID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `householdID` int(11) NOT NULL,
  `sessionid` int(11) NOT NULL AUTO_INCREMENT,
  `authtoken` varchar(500) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`sessionid`),
  KEY `householdID` (`householdID`),
  CONSTRAINT `session_ibfk_1` FOREIGN KEY (`householdID`) REFERENCES `household` (`householdID`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (1,2,'hYGeDeRUZqhqPDyGHO6iOjOau83pFfCZ+qR5r6AV1MNOJF8e43G9yMUlYkoCw2iMPQNA5IPio7eKjMDPa7NqsV1G4EomejRyHJUIJnwlwJob0FnIb5M4BA==','2014-07-31 16:57:50'),(1,3,'C3cRTpNGFG/BwacON+QVTD5E4GN8DgqlBtIWWZUvQpzHzn+V2h1o5H+BI8jkT7niC1/gUH3p6mkfhY4up9lbmMDGdmsSlKUqPp00Z67PUyynNO2+lzNMxQ==','2014-07-31 17:03:41'),(1,4,'QlDUjdMH2VdzSHkBfAIicK2wPTTgeZrh2U72PMhL7uZ10OiisCQ8ZkwaG4HJ1fMzYr5NwhRk2RfMiBbOkvF14hiTyJ611n8KM/aY6e8DpE3ozTxmyFwLSA==','2014-07-31 17:04:45'),(1,5,'smSA7wRjSWpggw4D0dXhFZOA3oWGvyCOZ4E0rFz30D2OPgsSbDznI63FjQgNUouxop4Uxm49Gm2K75nuQdCgU6uvN9s7vk5DD9RV0mwVdv90oyIZO67baw==','2014-07-31 17:05:25'),(1,6,'DpamCoNnRkNTgrURMCEV5izrcXoKuDozCNaTeupmYfKia7lMfhuwH8ltzoFax0Gatct+52PqmqIo7JJkO+basKvM0kYhhaBQoagAPOMjdRtGRlqwUyYqhA==','2014-07-31 17:07:37'),(1,7,'afNU6A1s6qw03vJMkBZ/bSuUGUAylMfnuLXnDDnVwwfJzvqId/7n7CLYXF2vKZ8VsdE48/Lt44irNtvcAZII4FKQjMLtnCU/i/rMpzfPiRXuJ4gIqSuUkA==','2014-07-31 17:08:18'),(1,8,'T7lH9naX7X2aZUNoZDeMyzMv9y1prYh5y2nKQNPzoSwGdO/iCGBkZ0DdWroEnE0meVVab8fu3P6gjtqR1ucHxEELduJG1HkTllbTNpWCd4DMeKisw866nA==','2014-07-31 17:22:04'),(1,9,'tYgb5g3uHkF2ttstLhNXzJfX3+o3y/KmCcRvLR0czNgdMeeUC86uZs4WqqeUBFyF/bb3yQQTjMBGHFpflRzPfVe1qIVaprU47ysBsJVGUgZ5UZdP+0vr0w==','2014-07-31 17:23:36'),(1,10,'umL52DkvtUt6TiduNAF9b/adC7lZroPqjvlhtcBLQL1ZXnrIB/sdhqfesacF+ZIWqrniHEKLx7z+FTvJfwUQmY/03reibN6T1JWx3E3T5iAtvute9VE7dg==','2014-07-31 17:40:29'),(1,11,'4h7OJadPrBVSNYH4BSXZKW4sTlgJPJoLB0RPJSPpGQg9YbLD7BR34YePug6jgesa0t/EoP9xIBZMCHpvbjc5kKkB5sfW3RaHhn1xsfQNswMXx9M6Q2acdQ==','2014-07-31 17:40:39'),(1,12,'Z3A2QkZIhrDIpItvEBMajtQSZ47/ckRpBLMLjdxHR2N/DGZ1BQRgbgPXqaSl6QgKVBwEurKFM3z5Vbz+IB3PpDs/+Ql+/1dRhdTHhgA5kcIsevJCWX0yZQ==','2014-07-31 17:41:54'),(1,13,'9++CqQW13F/cFBc7vR6Tx6g3wZykLtcZUjRrLCMllxH4xOsBINixnoiIi5ATTYg8IaooFo2H8/5GFFtqzWZvctlkyKdA2kCqADph8n9iOpliabYRD4NiPw==','2014-07-31 17:45:08'),(1,14,'4ngR7Yj4y0xcM9f7r5PZTDoqe25xYBHJtdxyVYgul1JjaOn2r3uOGuPvcRGyvvy0cbP4SbqivXBZx4fqSWr6Dlz42bahhpg5Ab9M50cnDRQsKFdeWpj/YA==','2014-07-31 17:58:34'),(1,15,'5IrOOaZ1akpefl5rI0nCN35o2G8ZTj0rnDy5ZYmdnAjB3s4YE4R4LG/e96xPfS9Tm7QPbjNqgRuM8txYnthO54TytViz495gTkxp9QmLeQEXyP3bLD1DfA==','2014-07-31 17:59:44'),(1,16,'khg6LOXu8JEZDB7ouXnI8Doe/hE3J7M71C53fbX4Mj6SdCb17zhcVuh1WIr5q0w8E+fu6vxkj80P+IZMceCsAQo2Wj7LboZixJyHRFQvIQaoSHwbK1YxFg==','2014-07-31 18:01:11'),(1,17,'cSv/Wjwb7BVR6GwtUgLylMrhVOw/424oxYHY5D78bT+YI5nBAywDG47zslaLi7i+Ju/GaWCYyh2zsnqpGvtf5gNgF4+iiGDqvab5iXiwMiRZFCU9PGm7ZQ==','2014-07-31 18:03:19'),(1,18,'EZ6wsCiSqxbjBXFWB7f4Vn/Q5RAVsVmdVx6s529AwPw4svHwNtr+n9hTix6i+bfTnsGhSehqi2xhHi8bRGv3d7b/XBNrRs3FE1sIPRuqbwKUXH9BoKJ08g==','2014-07-31 18:04:49'),(1,19,'gsfoU5kdYaLST06vA1dcg0vnhfo+7v7R5pQ2dxZZ57AKKQyhn1Z7lb9dNFuhNp6z7pywepY+6KhamAolsqeEbMRB92h1PVgGo7n/H94QpBhoMrFNtvYpbA==','2014-07-31 18:07:15'),(1,20,'XLTnuOQfu3BqWotBQ/ML+YCDtUmb5fMx3Ndw5sx66xwGYSDLYUmLKWCVPxfw+E779ByM+RbiNDUVNApmQkcI74CUBUAydFoi9Ur2wLXF/LSYffkRf/kDAA==','2014-07-31 18:19:12'),(1,21,'0v4tjlqfBmVR9gDz1bdPzK5rtIdRwL2fuRJSD8ViW1jofwcq2pcUuJoMrWFfKaWcVVT5BKW45U9r8VaAsR5KIlPjO9H9plEivklx6tUXK26987vbuO+OYA==','2014-07-31 18:19:50'),(1,22,'o9MKNU6rhe0xBDQBjuzT8/2umk/HdpJucTkCmtIBPF48INupuR0a/zOepAEkYLBs2G5tDlV9oI+g4pLuvw2MPVlZmbF3gM0OKnK1FErfFBhLjgP+rjYNtw==','2014-07-31 18:22:10'),(1,23,'XaeFjiGupdxj3sC8c9aNYOqvSjYxcfeyCePBr/bFfczPoLJR6y11jE0+94jqxHNfba5SCAaiPiLwriln1nRIfXKOv4wl59aAnQJ8KpWcmN1SS3m/UagJjQ==','2014-07-31 18:30:35'),(1,24,'vs08zqhTFLhrjiH6sS5ldD+HCDSj51Nnj3ypZsJZAQDlRn/r9KOzqQFOXmyeg8RTf3cVa2w+kzPeXzttPVQMbMIfD9MoJfYaaDaSEpATz8ycX2SaRs5J4Q==','2014-07-31 18:32:40'),(1,25,'KHiHv3SvYIzzQ6Jwy4I8XKAOjyBry9EzrHLPPz4zGX/WV/nSHJhpDVsKHiuNU4Wp8Cs0MAUaM9mFcyA1880uh8+Th6fRAgp1tTGA22cBi0tPP8lR4dBqqQ==','2014-07-31 18:33:42'),(1,26,'XUPYV9yl17JkLpDq/jIqJOwRnpsQETQRS+873vn/EVQxCokERAnIIZ7jy6ybKwO1bCM3mhplNLw5fhF1JltRh3c/igYhNZyCaFVMiQNuz0ZJqFK9qAjVEQ==','2014-07-31 18:34:04'),(1,27,'2dCpo90uFCYoX5M7D1oX04tInDItAGWHR+bplA7hrhVQdmWGe369JdE/ThLc9o+uhMssIe7EpDXeMrEfM0EICy8eQnX3ltRjIyui6DF1CjmiLZjVK6hzRg==','2014-07-31 18:34:54'),(1,28,'uc/bkRrWH/fyJsvkMgOTwfzkOvFzD6c88XSoMQtKIRImHXq4cQ8bAUgxi3nRRjRNSEw/AJxac7KHYYf/sRcj1PzyfBnbpNPWxlc43+CzI9+0pLoLGUA6vQ==','2014-07-31 18:44:10'),(1,29,'1X8JKGccJLyNPC0baXW1GUlSAbSZNW4hyigkHTDZ6A15WAm3bVHzVLI//nNyS+oNLOGQxgDOfledNsHmaMBzXseTU5mpd8RkFvAPmrx2R7dZaaYa+SKQoQ==','2014-08-01 09:56:12'),(1,30,'Xnf+MoBLwK015tZyGPi13mm4inp30R4FQzh05Q3+Hp+qJaeXeqqRixmLzxpdlwT2OPcrXI8CfVo/73HqHzrfdkfEcygX6qcFga7v1f47vIZ15V9rAgXNZA==','2014-08-01 09:58:20'),(1,31,'m6onFgx9LPC8CIpnZK4Lb0JZQK6z0vliZBzKiVp0NFHFF/44edQty+Vf5NxwUJKU6vEKqnHqscLvKKDEW5OJs+AaSVySQURhBGZV1Hm/JfMlomQLgeAdFQ==','2014-08-01 10:08:41'),(1,32,'Z1AWeZOGaoNfJs8sIVi+WiRxP+hByBl6c8a/kuQ+0xiJ2IKPSlvP4gMTBMA401r+jbiVGRP40XsCTzBjV6E8Vmm3DrE8Uv4Zi7ZWgUwaMhLM5eQfgiOZCQ==','2014-08-01 10:23:45'),(1,33,'YvTu2Jj0UvFCn5yyDd+VBUI4+jVKJ2loXUJPQjKPsiZjO5tv8JE9U3erJhz5noDoEpKhtq1QbxBnyFdVdjBMjBLOUptDUV83b87RiJ54fCrUAJkJKqfH8Q==','2014-08-01 10:24:35'),(1,34,'DQGWPJqZA2Lsf3EEIluHGRXUSenCzIZCVZRHC16AU+HkCgqrDbPzj1+OQuLgde4YLx5djnCitLRb/eFBvOy1jDjjRfp9gONUCqkDF/T/8MZA1MI2HYxHHA==','2014-08-01 10:25:08'),(1,35,'021AgfI3NyhCUqbNjJez9guxe9xrVRW5ubsPEarxr21CvificTc9pTuxReFBj3lpS0LhXSSIABgD1waQvJvu4fLJ3MsLdzFpDzLbAtnZ/smvnPmZ5cbAaw==','2014-08-01 10:27:10'),(1,36,'poaKpeO8AJOobL/p4gJqWaqdMILC9TTHL6vEitJIyAK2cHZtCPOx6i+kcsUrBsRgfygOPEYU794yOttVhqO1WWJBXq/AVR53/GH6PucEzTibG7mlXtc/UQ==','2014-08-01 10:28:23'),(1,37,'iPWE+oJZkf4LMr3jmeQ4e/LNWqYfT4/AxlDTh/fMiqF0u4tkavE8s7/bC4C8Yhark0m9sUubNLB3lxLwxkkFiZUpQiEWuur9Z/mq2re8UnsuZcrddU9y9w==','2014-08-01 10:35:35'),(1,38,'ZnYcSYsN3iL5JgjKvQlZthtyN43oIKrgBopaYgrBEe98ajLWCteHrzISkRJ43nLfRaL142Lcxwr3F2CLcDPuZyLPnUWoMOTfTlKlK4ZOLEWcRdqQx0ODKw==','2014-08-01 10:37:22'),(1,39,'PahdyjwYVvkvGlCxZkuI/NwEbvUpLQRr3H6rHqmdrZtmRLayCJNkPYneBhsrj9tgtf2JG4sQoHoE8RZPK/Eak5ePPm/VJP+qZfPh088QbmupL7ceJYCn7w==','2014-08-01 10:38:13'),(1,40,'pKtKHtlBzD79ZYA7cMdL7y4yMME1KNYFBly5csPNBjMF6LtKIzFDQIjMd3Aq4GbsMfvfzcTtAdh1pHZuMpbJmhC9FMa/qBF3H1ccNG4ksFK8XT08Plwk5Q==','2014-08-01 10:52:53'),(1,41,'stFgU0c2GQfo+IoJmFls8ph4Lemk+X2Ljbln8eavIuYbnhPanOUTHs0a6zE3mwqKHSJ0FNQgYHB20p16cAztp/W707i3ENxozt7OjXY7QSXJ159RS42psg==','2014-08-01 11:09:59'),(1,42,'TRXGVyn3L+b7yen1nFEszfSQCRaQAt+BQxCVMCc86ITP1UhurYyDmvDOhAiVRq/yEKHZE6PYuhYRcc+Lioleje3kvReAuGP8kCo23a/VKyGptTvXgPtHow==','2014-08-01 11:12:53'),(1,43,'AzexrMtbuI1EaZ4DbvXgEFZ1i/eeelwOeEjtMAQS+BPtrRYHSprnRK82/kqoiG72ocfwd5K9v7ytHap/EFRoGQ3f27lGSD5t62BVxM9DFiZ48/SRlQlRbQ==','2014-08-01 11:13:14'),(1,44,'7EQKtzcDid5laZ5QY+rOe3tRaSigKBdao4b1G5nTZk7ApLWMJMD/abRlelD9Kxr6Emvh9bxOPD7cHMd9M8gOxabuCCJJX1Kj4zebpNcgRYutM+J1tZsJIA==','2014-08-01 11:18:09'),(1,45,'Ezga5VB+YiBFMsKeqhg9krVPsCb+prxbpp00xS3vT7nBk/iOMiwfZ94D7YleBc/3Ggb9Cnakve61VNibCv6zXKrX7Zg7HGZmfW+lMTTmfoWFF0ve1pU3gg==','2014-08-01 11:22:02'),(1,46,'3yAl9amq8vH7uqRFxZjLh2i8v+WlO2iTN62KtO9PyEuVYBs0Eme+ALbN+x2saz8TRulTkkwFSNrIEKeom//7ehSduutJBe7eGTN7QQ675E2Z4w4wpALNaw==','2014-08-01 11:24:54'),(1,47,'+nbGOTTKvtQvh/gx/W5W8rIh+e+mp3p8lX6XoMxBW9KVvavYG/0zVXBTGe3MiA0noV8ekDpiHX76tRJpwhg24dbR7ZEfoNgIFteMIb7qmHARzA1HBohDVQ==','2014-08-01 11:25:15'),(1,48,'yk/UITi5XOnOjqSUK9EFsPRradmlMae34+OP8/XFVxyG2GQzGdFuSp/+5bIEeQQcftFopiQzEpVp6rCnGVfFzyF3uc5dahP004HNDGbYlTFY7Sk0+wNQOg==','2014-08-01 13:33:14'),(1,49,'fM9bez5wcZK3RDvWdQ6sDl+SuDs445bF2rVao5UpED8JiC+8e2mBI2FqaTAkFC4u7BUoP0eQU10JZHNLVhuxk/Wl9mO33UFFpCdU1/2UPjitt1xfzqrgJw==','2014-08-01 13:52:31'),(1,50,'9IHVRatgxIFuoWCiL4smDmjvPM49KqTTOMd8KcUgxe7BXRacj3MnPdlQxAmdi1M8EJaydo5yxVtsegG2rHyvd/ObT/HBmIJwdzYEsqplyPylQVMrKC1evA==','2014-08-01 13:58:12'),(1,51,'8k8Eoopsw3weMq7U0iHjtedU4SAmXp00Ey6X20Gv2yzy1aYQ3ppSkFfvDFwdEh2e4afi6SJGzekUm2p6e34gRIxM11pCX1Y+nZPeYJUOJ/E2vwvDPvQLIQ==','2014-08-01 14:08:39'),(1,52,'ApDjb+kGWQWrX9r6UVa6qU8WTrR2Z+hR/nJaozNeTKqX+Z077O8gWsmc4DBaYbt1NRYgUWsadsvzFmLTSRMEmmnjlLK4HIE2hSwQMdHuNtAZiUtq254jbA==','2014-08-01 14:10:11'),(1,53,'3chT3oX/C15b4zqxtIMdnpVH19ahmJgrf0bR1kD023S4+pDN/gDE52yp89vu6Dhd/mvxeSMHTpGVin8nVTQfuxuqBEqifNCtsqg1G+MVBEA8xeerL9j66Q==','2014-08-01 14:20:59'),(1,54,'xrVwCs8lGjJ2yGj7XQeukdYT1XviqCQLqOyd5E5Lrrh4mUOaA1RvmP8PNU8ZKOAvJPkZF9VHfeZxSmew2VuGFuDNhu9O47TRzDbrcRWGhtMLG17gi+XXZA==','2014-08-01 17:42:22'),(1,55,'C9ND4By4bGdNXXr5Uf+JvUmis0aT8uTd/j/eSKQFqeF+m76qPQZfeSpxiYwvJuB3ZUfSy0VHPPeEOnt2pyVpQNbQ2BoodtnNYFAucX2WaXOMBlxAhed1UQ==','2014-08-01 17:53:47');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social`
--

DROP TABLE IF EXISTS `social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social` (
  `userid` varchar(10) NOT NULL,
  `facebook_token` varchar(300) DEFAULT NULL,
  `facebook_token_expiry` datetime DEFAULT NULL,
  `soundcloud_token_expiry` datetime DEFAULT NULL,
  `soundcloud_token` varchar(300) DEFAULT NULL,
  `youtube_token` varchar(300) DEFAULT NULL,
  `youtube_token_expiry` datetime DEFAULT NULL,
  `dailymotion_token_expiry` datetime DEFAULT NULL,
  `dailymotion_token` varchar(300) DEFAULT NULL,
  UNIQUE KEY `userid` (`userid`),
  CONSTRAINT `social_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social`
--

LOCK TABLES `social` WRITE;
/*!40000 ALTER TABLE `social` DISABLE KEYS */;
INSERT INTO `social` VALUES ('3','CAAVchVpScegBAPxZC7rPHMcqknl3if7wkSV2xAPOTOBDHyEapnnJNvZCXs7xlu5HuXUVy77uZCgvaZAdMe1QrZCm2qGzhKtwPxyekS8jXFYexK9CD12RUWHN3LIYF1iouespxqxoF0FgU8GwQ5MwsPcxDfwY0bmFvDmd8Cl0BEvAGuvfdcnzvw53pi4otDgsZD','2014-07-27 23:22:56','0000-00-00 00:00:00','1-81943-82823848-6c9cbd758e9556a',NULL,NULL,'2014-06-16 01:45:16','OWNFVgFZSAETHFVKGBgIXBQbFQcLFFNKHw'),('iori25','CAAVchVpScegBAOOrYZB3xdAAUwdDCyWM3QtMNScdhCClB8wL5h6njcTEmDIvZBajVA0AAY8McAXfPzCOJwOZCnjZAyjufp6po0MICDEtYvTNJZBNPxGTCMNiwbIKwdrG09E8JrSBc2KZBpMTXjxf90cKHneOngnZCT1be7mZA4VjvUgJeLKPmNZBUjes2O9zcwZAwZD','2014-07-27 23:22:56','0000-00-00 00:00:00','1-81943-82823848-9fbbf32e26e259a',NULL,NULL,'2014-06-15 02:05:18','ZDkSUVddTkISBAwRVUAMXFFPCBdVDQpcWQ'),('koustubh25','CAAVchVpScegBAMfrDYBMeN3qw1YKLX4fXtQsaZAWXwfvWWgRBC8frM46l8yZBPVZCHPDdgMPhsWNOkQQaT5O1oo0gHCFIVFlbRSxMV5C1HnaprnjQoGvPU9ue2vaQ6RzaC4F0YZB7dOQiGGuahppnsRuhDn2nmszZBuxH47gNaGlkCKMhAWAOIg1y1B1WjU4ZD','2014-07-29 20:15:48','0000-00-00 00:00:00','1-81943-82823848-65f1d712eab84cc',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `prof_pic` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `householdID` int(11) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `current_location` varchar(20) DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `parental_rating` int(11) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `householdID` (`householdID`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`householdID`) REFERENCES `household` (`householdID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('/pics/test1.png','kosta250@gmail.com',1,'3','test','M','1989-04-15','pune','2014-05-29 00:08:14','2014-05-29 00:08:14',10,'test','95136'),('https://idaas-vcsui.dlinkddns.com:8443/IDaaS/pics/iomz.png','iomz@cisco.com',1,'iori25','lori','M','1989-03-30','SAN JOSE','2014-05-14 14:28:52','2014-05-14 14:28:52',NULL,'iori','95136'),('https://idaas-vcsui.dlinkddns.com:8443/IDaaS/pics/kougaikw.png','kougaikw@cisco.com',1,'koustubh25','koustubh','M','1989-04-15','SAN JOSE','2014-05-14 12:29:03','2014-05-14 12:29:03',NULL,'koustubh','95136');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-02 20:39:30
